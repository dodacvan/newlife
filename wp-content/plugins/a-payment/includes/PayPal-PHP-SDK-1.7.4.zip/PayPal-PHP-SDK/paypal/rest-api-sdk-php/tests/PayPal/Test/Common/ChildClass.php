<?php
namespace PayPal\Test\Common;

class ChildClass extends SimpleClass
{
}
